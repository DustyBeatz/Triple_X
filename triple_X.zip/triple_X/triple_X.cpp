#include <iostream> 
#include <ctime>
void PrintIntroduction(int Difficulty)
{
     //print welcome messages to terminal
    std::cout << "\nListen up Operative! You're a hacker sent to break into a level " << Difficulty;
    std::cout << " secure firewall. \n We need access the base schematics. Break through the firewall by using the correct security codes... \n";

}


bool PlayGame(int Difficulty, int DifficultyLimit)//  1st expression statements shows the instructions and the 2nd shows the problem. 
            //the variables are the codes that is to be solved. 
{
       PrintIntroduction(Difficulty);
//delcare three number code
    const int CodeA = rand() % DifficultyLimit +1;
    const int CodeB = rand() % DifficultyLimit +1;
    const int CodeC = rand() % DifficultyLimit +1;

     int CodeSum = CodeA + CodeB + CodeC;
     int CodeProduct = CodeA * CodeB * CodeC;

// print sum and product to the terminal
    std::cout << std::endl;
    std::cout << "There are three numbers in the code\n";
    std::cout << "The codes add up to: " << CodeSum;
    std::cout << std::endl;
    std::cout << "When the codes are multipled the total comes to: " << CodeProduct;

    int GuessA, GuessB, GuessC;// store player guess
 

 
    std::cout << std::endl;
    std::cin >> GuessA >> GuessB >> GuessC;


    int GuessSum = GuessA + GuessB + GuessC;
    int GuessProduct = GuessA * GuessB * GuessC; 
    
    //check if the player guessed correctly
    if(GuessSum == CodeSum && GuessProduct == CodeProduct)
    {
        std::cout << "\nYou have broken pass the firewall!\n";
        return(true);
    }

    else
    {
        std::cout << "\nThat was the wrong code! Try again! \n";
        return(false);
    }
  

}

int main() 
{
    srand(time(NULL));
    int limit = 3;
    int LevelDifficulty = 1;
    int const MaxLevel = 5;
   

    while (LevelDifficulty <= MaxLevel) //loop game until all levels are completed
 {
    bool bLevelComplete = PlayGame(LevelDifficulty, limit);
    std::cin.clear(); //clears any errors
    std::cin.ignore(); //discards the buffers

    if (bLevelComplete) 
    {
        //increase level difficulty
        ++LevelDifficulty;
        ++ limit;
    }

 }
    std::cout << "\nWell done operative the schematics of the base were succefully uploaded. Return to base for breifing.\n";
    return 0;
}